<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>AdminLTE 3 | Log in (v2)</title>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>

<body class="hold-transition login-page" style="background-color:#000000;">
    <div id="app">
        <router-view>
            <Login />
        </router-view>
    </div>
</body>

</html>
<?php /**PATH K:\Multipurpose-Laravel9-and-Vue3-Application-main\vue_app\resources\views/auth/login.blade.php ENDPATH**/ ?>