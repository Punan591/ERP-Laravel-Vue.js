<?php

return [
    'default' => [
        'app_name' => 'Punan Creation',
        'date_format' => 'm/d/Y',
        'pagination_limit' => 10,
    ],
];
